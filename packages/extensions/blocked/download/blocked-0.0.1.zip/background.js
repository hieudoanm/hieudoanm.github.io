/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/*!***************************!*\
  !*** ./src/background.ts ***!
  \***************************/

const BLOCKED_SITES = [
    'facebook.com',
    'twitter.com',
    'instagram.com',
    'youtube.com',
    'tiktok.com',
];
/** Helper: Check if URL is blocked */
function isBlocked(url) {
    try {
        const hostname = new URL(url).hostname;
        console.log('[Focus] Checking hostname:', hostname);
        const matched = BLOCKED_SITES.some((site) => hostname.includes(site));
        console.log('[Focus] Matched blocked site?', matched);
        return matched;
    }
    catch (err) {
        console.error('[Focus] Error parsing URL:', url, err);
        return false;
    }
}
/** Listener: Intercept and redirect blocked sites */
console.log('[Focus] Background script loaded');
browser.webRequest.onBeforeRequest.addListener((details) => {
    console.log('[Focus] Intercepted request:', details.url);
    if (isBlocked(details.url)) {
        try {
            const blockedPage = browser.runtime.getURL('blocked.html');
            console.log('[Focus] Blocking and redirecting tab', details.tabId, 'to', blockedPage); // Cancel the request
            browser.tabs.update(details.tabId, { url: blockedPage });
            return { cancel: true };
        }
        catch (error) {
            console.error('[Focus] Redirect error:', error);
        }
    }
    else {
        console.log('[Focus] URL not blocked:', details.url);
    }
}, { urls: ['<all_urls>'], types: ['main_frame'] }, ['blocking']);

/******/ })()
;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiYmFja2dyb3VuZC5qcyIsIm1hcHBpbmdzIjoiOzs7OztBQUFhO0FBQ2I7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxtR0FBbUc7QUFDbkcsaURBQWlELGtCQUFrQjtBQUNuRSxxQkFBcUI7QUFDckI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLENBQUMsSUFBSSw2Q0FBNkMiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9AaGlldWRvYW5tL2Jsb2NrZWQvLi9zcmMvYmFja2dyb3VuZC50cyJdLCJzb3VyY2VzQ29udGVudCI6WyJcInVzZSBzdHJpY3RcIjtcbmNvbnN0IEJMT0NLRURfU0lURVMgPSBbXG4gICAgJ2ZhY2Vib29rLmNvbScsXG4gICAgJ3R3aXR0ZXIuY29tJyxcbiAgICAnaW5zdGFncmFtLmNvbScsXG4gICAgJ3lvdXR1YmUuY29tJyxcbiAgICAndGlrdG9rLmNvbScsXG5dO1xuLyoqIEhlbHBlcjogQ2hlY2sgaWYgVVJMIGlzIGJsb2NrZWQgKi9cbmZ1bmN0aW9uIGlzQmxvY2tlZCh1cmwpIHtcbiAgICB0cnkge1xuICAgICAgICBjb25zdCBob3N0bmFtZSA9IG5ldyBVUkwodXJsKS5ob3N0bmFtZTtcbiAgICAgICAgY29uc29sZS5sb2coJ1tGb2N1c10gQ2hlY2tpbmcgaG9zdG5hbWU6JywgaG9zdG5hbWUpO1xuICAgICAgICBjb25zdCBtYXRjaGVkID0gQkxPQ0tFRF9TSVRFUy5zb21lKChzaXRlKSA9PiBob3N0bmFtZS5pbmNsdWRlcyhzaXRlKSk7XG4gICAgICAgIGNvbnNvbGUubG9nKCdbRm9jdXNdIE1hdGNoZWQgYmxvY2tlZCBzaXRlPycsIG1hdGNoZWQpO1xuICAgICAgICByZXR1cm4gbWF0Y2hlZDtcbiAgICB9XG4gICAgY2F0Y2ggKGVycikge1xuICAgICAgICBjb25zb2xlLmVycm9yKCdbRm9jdXNdIEVycm9yIHBhcnNpbmcgVVJMOicsIHVybCwgZXJyKTtcbiAgICAgICAgcmV0dXJuIGZhbHNlO1xuICAgIH1cbn1cbi8qKiBMaXN0ZW5lcjogSW50ZXJjZXB0IGFuZCByZWRpcmVjdCBibG9ja2VkIHNpdGVzICovXG5jb25zb2xlLmxvZygnW0ZvY3VzXSBCYWNrZ3JvdW5kIHNjcmlwdCBsb2FkZWQnKTtcbmJyb3dzZXIud2ViUmVxdWVzdC5vbkJlZm9yZVJlcXVlc3QuYWRkTGlzdGVuZXIoKGRldGFpbHMpID0+IHtcbiAgICBjb25zb2xlLmxvZygnW0ZvY3VzXSBJbnRlcmNlcHRlZCByZXF1ZXN0OicsIGRldGFpbHMudXJsKTtcbiAgICBpZiAoaXNCbG9ja2VkKGRldGFpbHMudXJsKSkge1xuICAgICAgICB0cnkge1xuICAgICAgICAgICAgY29uc3QgYmxvY2tlZFBhZ2UgPSBicm93c2VyLnJ1bnRpbWUuZ2V0VVJMKCdibG9ja2VkLmh0bWwnKTtcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKCdbRm9jdXNdIEJsb2NraW5nIGFuZCByZWRpcmVjdGluZyB0YWInLCBkZXRhaWxzLnRhYklkLCAndG8nLCBibG9ja2VkUGFnZSk7IC8vIENhbmNlbCB0aGUgcmVxdWVzdFxuICAgICAgICAgICAgYnJvd3Nlci50YWJzLnVwZGF0ZShkZXRhaWxzLnRhYklkLCB7IHVybDogYmxvY2tlZFBhZ2UgfSk7XG4gICAgICAgICAgICByZXR1cm4geyBjYW5jZWw6IHRydWUgfTtcbiAgICAgICAgfVxuICAgICAgICBjYXRjaCAoZXJyb3IpIHtcbiAgICAgICAgICAgIGNvbnNvbGUuZXJyb3IoJ1tGb2N1c10gUmVkaXJlY3QgZXJyb3I6JywgZXJyb3IpO1xuICAgICAgICB9XG4gICAgfVxuICAgIGVsc2Uge1xuICAgICAgICBjb25zb2xlLmxvZygnW0ZvY3VzXSBVUkwgbm90IGJsb2NrZWQ6JywgZGV0YWlscy51cmwpO1xuICAgIH1cbn0sIHsgdXJsczogWyc8YWxsX3VybHM+J10sIHR5cGVzOiBbJ21haW5fZnJhbWUnXSB9LCBbJ2Jsb2NraW5nJ10pO1xuIl0sIm5hbWVzIjpbXSwic291cmNlUm9vdCI6IiJ9