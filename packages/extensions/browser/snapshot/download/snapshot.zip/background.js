/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	var __webpack_modules__ = ({

/***/ "./src/background.ts"
/*!***************************!*\
  !*** ./src/background.ts ***!
  \***************************/
() {


// background.js – Service Worker
// Handles captureVisibleTab which must run from background context
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message.action === 'captureTab') {
        const { format, quality } = message;
        const options = {
            format: format === 'png' ? 'png' : 'jpeg',
        };
        if (format !== 'png' && quality) {
            options.quality = quality;
        }
        // For webp: Chrome's captureVisibleTab doesn't support webp natively,
        // so we capture as PNG and re-encode via OffscreenCanvas if needed.
        const captureFormat = format === 'jpeg' ? 'jpeg' : 'png';
        const captureOptions = {
            format: captureFormat,
        };
        if (captureFormat === 'jpeg')
            captureOptions.quality = quality || 92;
        chrome.tabs.captureVisibleTab(chrome.windows.WINDOW_ID_CURRENT, captureOptions, (dataUrl) => {
            if (chrome.runtime.lastError) {
                sendResponse('ERROR:' + chrome.runtime.lastError.message);
                return;
            }
            if (format === 'webp') {
                // Re-encode to webp using OffscreenCanvas
                reencodeAsWebP(dataUrl, quality || 92)
                    .then((webpUrl) => sendResponse(webpUrl))
                    .catch(() => sendResponse(dataUrl)); // fallback: return original png
            }
            else {
                sendResponse(dataUrl);
            }
        });
        return true; // Keep message channel open for async response
    }
});
function reencodeAsWebP(pngDataUrl, quality) {
    return __awaiter(this, void 0, void 0, function* () {
        const res = yield fetch(pngDataUrl);
        const blob = yield res.blob();
        const bitmap = yield createImageBitmap(blob);
        const canvas = new OffscreenCanvas(bitmap.width, bitmap.height);
        const ctx = canvas.getContext('2d');
        ctx === null || ctx === void 0 ? void 0 : ctx.drawImage(bitmap, 0, 0);
        const webpBlob = yield canvas.convertToBlob({
            type: 'image/webp',
            quality: quality / 100,
        });
        return new Promise((resolve) => {
            const reader = new FileReader();
            reader.onloadend = () => resolve(reader.result);
            reader.readAsDataURL(webpBlob);
        });
    });
}


/***/ }

/******/ 	});
/************************************************************************/
/******/ 	
/******/ 	// startup
/******/ 	// Load entry module and return exports
/******/ 	// This entry module is referenced by other modules so it can't be inlined
/******/ 	var __webpack_exports__ = {};
/******/ 	__webpack_modules__["./src/background.ts"].call(__webpack_exports__);
/******/ 	
/******/ })()
;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiYmFja2dyb3VuZC5qcyIsIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7O0FBQWE7QUFDYjtBQUNBO0FBQ0E7QUFDQSw0QkFBNEIsK0RBQStELGlCQUFpQjtBQUM1RztBQUNBLG9DQUFvQyxNQUFNLCtCQUErQixZQUFZO0FBQ3JGLG1DQUFtQyxNQUFNLG1DQUFtQyxZQUFZO0FBQ3hGLGdDQUFnQztBQUNoQztBQUNBLEtBQUs7QUFDTDtBQUNBO0FBQ0E7QUFDQSxnQkFBZ0Isa0JBQWtCO0FBQ2xDO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSx5REFBeUQ7QUFDekQ7QUFDQTtBQUNBO0FBQ0E7QUFDQSxTQUFTO0FBQ1QscUJBQXFCO0FBQ3JCO0FBQ0EsQ0FBQztBQUNEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxTQUFTO0FBQ1Q7QUFDQTtBQUNBO0FBQ0E7QUFDQSxTQUFTO0FBQ1QsS0FBSztBQUNMOzs7Ozs7OztVRWpFQTtVQUNBO1VBQ0E7VUFDQTtVQUNBIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vQGhpZXVkb2FubS9zbmFwc2hvdC8uL3NyYy9iYWNrZ3JvdW5kLnRzIiwid2VicGFjazovL0BoaWV1ZG9hbm0vc25hcHNob3Qvd2VicGFjay9iZWZvcmUtc3RhcnR1cCIsIndlYnBhY2s6Ly9AaGlldWRvYW5tL3NuYXBzaG90L3dlYnBhY2svc3RhcnR1cCIsIndlYnBhY2s6Ly9AaGlldWRvYW5tL3NuYXBzaG90L3dlYnBhY2svYWZ0ZXItc3RhcnR1cCJdLCJzb3VyY2VzQ29udGVudCI6WyJcInVzZSBzdHJpY3RcIjtcbi8vIGJhY2tncm91bmQuanMg4oCTIFNlcnZpY2UgV29ya2VyXG4vLyBIYW5kbGVzIGNhcHR1cmVWaXNpYmxlVGFiIHdoaWNoIG11c3QgcnVuIGZyb20gYmFja2dyb3VuZCBjb250ZXh0XG52YXIgX19hd2FpdGVyID0gKHRoaXMgJiYgdGhpcy5fX2F3YWl0ZXIpIHx8IGZ1bmN0aW9uICh0aGlzQXJnLCBfYXJndW1lbnRzLCBQLCBnZW5lcmF0b3IpIHtcbiAgICBmdW5jdGlvbiBhZG9wdCh2YWx1ZSkgeyByZXR1cm4gdmFsdWUgaW5zdGFuY2VvZiBQID8gdmFsdWUgOiBuZXcgUChmdW5jdGlvbiAocmVzb2x2ZSkgeyByZXNvbHZlKHZhbHVlKTsgfSk7IH1cbiAgICByZXR1cm4gbmV3IChQIHx8IChQID0gUHJvbWlzZSkpKGZ1bmN0aW9uIChyZXNvbHZlLCByZWplY3QpIHtcbiAgICAgICAgZnVuY3Rpb24gZnVsZmlsbGVkKHZhbHVlKSB7IHRyeSB7IHN0ZXAoZ2VuZXJhdG9yLm5leHQodmFsdWUpKTsgfSBjYXRjaCAoZSkgeyByZWplY3QoZSk7IH0gfVxuICAgICAgICBmdW5jdGlvbiByZWplY3RlZCh2YWx1ZSkgeyB0cnkgeyBzdGVwKGdlbmVyYXRvcltcInRocm93XCJdKHZhbHVlKSk7IH0gY2F0Y2ggKGUpIHsgcmVqZWN0KGUpOyB9IH1cbiAgICAgICAgZnVuY3Rpb24gc3RlcChyZXN1bHQpIHsgcmVzdWx0LmRvbmUgPyByZXNvbHZlKHJlc3VsdC52YWx1ZSkgOiBhZG9wdChyZXN1bHQudmFsdWUpLnRoZW4oZnVsZmlsbGVkLCByZWplY3RlZCk7IH1cbiAgICAgICAgc3RlcCgoZ2VuZXJhdG9yID0gZ2VuZXJhdG9yLmFwcGx5KHRoaXNBcmcsIF9hcmd1bWVudHMgfHwgW10pKS5uZXh0KCkpO1xuICAgIH0pO1xufTtcbmNocm9tZS5ydW50aW1lLm9uTWVzc2FnZS5hZGRMaXN0ZW5lcigobWVzc2FnZSwgc2VuZGVyLCBzZW5kUmVzcG9uc2UpID0+IHtcbiAgICBpZiAobWVzc2FnZS5hY3Rpb24gPT09ICdjYXB0dXJlVGFiJykge1xuICAgICAgICBjb25zdCB7IGZvcm1hdCwgcXVhbGl0eSB9ID0gbWVzc2FnZTtcbiAgICAgICAgY29uc3Qgb3B0aW9ucyA9IHtcbiAgICAgICAgICAgIGZvcm1hdDogZm9ybWF0ID09PSAncG5nJyA/ICdwbmcnIDogJ2pwZWcnLFxuICAgICAgICB9O1xuICAgICAgICBpZiAoZm9ybWF0ICE9PSAncG5nJyAmJiBxdWFsaXR5KSB7XG4gICAgICAgICAgICBvcHRpb25zLnF1YWxpdHkgPSBxdWFsaXR5O1xuICAgICAgICB9XG4gICAgICAgIC8vIEZvciB3ZWJwOiBDaHJvbWUncyBjYXB0dXJlVmlzaWJsZVRhYiBkb2Vzbid0IHN1cHBvcnQgd2VicCBuYXRpdmVseSxcbiAgICAgICAgLy8gc28gd2UgY2FwdHVyZSBhcyBQTkcgYW5kIHJlLWVuY29kZSB2aWEgT2Zmc2NyZWVuQ2FudmFzIGlmIG5lZWRlZC5cbiAgICAgICAgY29uc3QgY2FwdHVyZUZvcm1hdCA9IGZvcm1hdCA9PT0gJ2pwZWcnID8gJ2pwZWcnIDogJ3BuZyc7XG4gICAgICAgIGNvbnN0IGNhcHR1cmVPcHRpb25zID0ge1xuICAgICAgICAgICAgZm9ybWF0OiBjYXB0dXJlRm9ybWF0LFxuICAgICAgICB9O1xuICAgICAgICBpZiAoY2FwdHVyZUZvcm1hdCA9PT0gJ2pwZWcnKVxuICAgICAgICAgICAgY2FwdHVyZU9wdGlvbnMucXVhbGl0eSA9IHF1YWxpdHkgfHwgOTI7XG4gICAgICAgIGNocm9tZS50YWJzLmNhcHR1cmVWaXNpYmxlVGFiKGNocm9tZS53aW5kb3dzLldJTkRPV19JRF9DVVJSRU5ULCBjYXB0dXJlT3B0aW9ucywgKGRhdGFVcmwpID0+IHtcbiAgICAgICAgICAgIGlmIChjaHJvbWUucnVudGltZS5sYXN0RXJyb3IpIHtcbiAgICAgICAgICAgICAgICBzZW5kUmVzcG9uc2UoJ0VSUk9SOicgKyBjaHJvbWUucnVudGltZS5sYXN0RXJyb3IubWVzc2FnZSk7XG4gICAgICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgaWYgKGZvcm1hdCA9PT0gJ3dlYnAnKSB7XG4gICAgICAgICAgICAgICAgLy8gUmUtZW5jb2RlIHRvIHdlYnAgdXNpbmcgT2Zmc2NyZWVuQ2FudmFzXG4gICAgICAgICAgICAgICAgcmVlbmNvZGVBc1dlYlAoZGF0YVVybCwgcXVhbGl0eSB8fCA5MilcbiAgICAgICAgICAgICAgICAgICAgLnRoZW4oKHdlYnBVcmwpID0+IHNlbmRSZXNwb25zZSh3ZWJwVXJsKSlcbiAgICAgICAgICAgICAgICAgICAgLmNhdGNoKCgpID0+IHNlbmRSZXNwb25zZShkYXRhVXJsKSk7IC8vIGZhbGxiYWNrOiByZXR1cm4gb3JpZ2luYWwgcG5nXG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgICAgICBzZW5kUmVzcG9uc2UoZGF0YVVybCk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH0pO1xuICAgICAgICByZXR1cm4gdHJ1ZTsgLy8gS2VlcCBtZXNzYWdlIGNoYW5uZWwgb3BlbiBmb3IgYXN5bmMgcmVzcG9uc2VcbiAgICB9XG59KTtcbmZ1bmN0aW9uIHJlZW5jb2RlQXNXZWJQKHBuZ0RhdGFVcmwsIHF1YWxpdHkpIHtcbiAgICByZXR1cm4gX19hd2FpdGVyKHRoaXMsIHZvaWQgMCwgdm9pZCAwLCBmdW5jdGlvbiogKCkge1xuICAgICAgICBjb25zdCByZXMgPSB5aWVsZCBmZXRjaChwbmdEYXRhVXJsKTtcbiAgICAgICAgY29uc3QgYmxvYiA9IHlpZWxkIHJlcy5ibG9iKCk7XG4gICAgICAgIGNvbnN0IGJpdG1hcCA9IHlpZWxkIGNyZWF0ZUltYWdlQml0bWFwKGJsb2IpO1xuICAgICAgICBjb25zdCBjYW52YXMgPSBuZXcgT2Zmc2NyZWVuQ2FudmFzKGJpdG1hcC53aWR0aCwgYml0bWFwLmhlaWdodCk7XG4gICAgICAgIGNvbnN0IGN0eCA9IGNhbnZhcy5nZXRDb250ZXh0KCcyZCcpO1xuICAgICAgICBjdHggPT09IG51bGwgfHwgY3R4ID09PSB2b2lkIDAgPyB2b2lkIDAgOiBjdHguZHJhd0ltYWdlKGJpdG1hcCwgMCwgMCk7XG4gICAgICAgIGNvbnN0IHdlYnBCbG9iID0geWllbGQgY2FudmFzLmNvbnZlcnRUb0Jsb2Ioe1xuICAgICAgICAgICAgdHlwZTogJ2ltYWdlL3dlYnAnLFxuICAgICAgICAgICAgcXVhbGl0eTogcXVhbGl0eSAvIDEwMCxcbiAgICAgICAgfSk7XG4gICAgICAgIHJldHVybiBuZXcgUHJvbWlzZSgocmVzb2x2ZSkgPT4ge1xuICAgICAgICAgICAgY29uc3QgcmVhZGVyID0gbmV3IEZpbGVSZWFkZXIoKTtcbiAgICAgICAgICAgIHJlYWRlci5vbmxvYWRlbmQgPSAoKSA9PiByZXNvbHZlKHJlYWRlci5yZXN1bHQpO1xuICAgICAgICAgICAgcmVhZGVyLnJlYWRBc0RhdGFVUkwod2VicEJsb2IpO1xuICAgICAgICB9KTtcbiAgICB9KTtcbn1cbiIsIiIsIi8vIHN0YXJ0dXBcbi8vIExvYWQgZW50cnkgbW9kdWxlIGFuZCByZXR1cm4gZXhwb3J0c1xuLy8gVGhpcyBlbnRyeSBtb2R1bGUgaXMgcmVmZXJlbmNlZCBieSBvdGhlciBtb2R1bGVzIHNvIGl0IGNhbid0IGJlIGlubGluZWRcbnZhciBfX3dlYnBhY2tfZXhwb3J0c19fID0ge307XG5fX3dlYnBhY2tfbW9kdWxlc19fW1wiLi9zcmMvYmFja2dyb3VuZC50c1wiXS5jYWxsKF9fd2VicGFja19leHBvcnRzX18pO1xuIiwiIl0sIm5hbWVzIjpbXSwic291cmNlUm9vdCI6IiJ9