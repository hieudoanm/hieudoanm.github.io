/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/*!***************************!*\
  !*** ./src/background.ts ***!
  \***************************/

// Background script for Block Sites Extension
// Default list of blocked site domains
const DEFAULT_BLOCKED_SITES = [
    'facebook.com',
    'twitter.com',
    'reddit.com',
    'tiktok.com',
];
const BLOCKED_URL_PATTERNS = DEFAULT_BLOCKED_SITES.map((domain) => `*://*.${domain}/*`);
const isManifestV2 = typeof chrome.webRequest !== 'undefined';
if (isManifestV2) {
    chrome.webRequest.onBeforeRequest.addListener(() => {
        console.log('[BlockSites] Blocked site request');
        return { cancel: true };
    }, { urls: BLOCKED_URL_PATTERNS }, ['blocking']);
    console.log('[BlockSites] WebRequest block rules initialized (Manifest V2).');
}
else {
    chrome.runtime.onInstalled.addListener(() => {
        console.log('[BlockSites] DeclarativeNetRequest rules initialized (Manifest V3).');
    });
}

/******/ })()
;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiYmFja2dyb3VuZC5qcyIsIm1hcHBpbmdzIjoiOzs7OztBQUFhO0FBQ2I7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLDRFQUE0RSxPQUFPO0FBQ25GO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsaUJBQWlCO0FBQ2pCLEtBQUssSUFBSSw0QkFBNEI7QUFDckM7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEtBQUs7QUFDTCIsInNvdXJjZXMiOlsid2VicGFjazovL0BibG9jay9zaXRlcy8uL3NyYy9iYWNrZ3JvdW5kLnRzIl0sInNvdXJjZXNDb250ZW50IjpbIlwidXNlIHN0cmljdFwiO1xuLy8gQmFja2dyb3VuZCBzY3JpcHQgZm9yIEJsb2NrIFNpdGVzIEV4dGVuc2lvblxuLy8gRGVmYXVsdCBsaXN0IG9mIGJsb2NrZWQgc2l0ZSBkb21haW5zXG5jb25zdCBERUZBVUxUX0JMT0NLRURfU0lURVMgPSBbXG4gICAgJ2ZhY2Vib29rLmNvbScsXG4gICAgJ3R3aXR0ZXIuY29tJyxcbiAgICAncmVkZGl0LmNvbScsXG4gICAgJ3Rpa3Rvay5jb20nLFxuXTtcbmNvbnN0IEJMT0NLRURfVVJMX1BBVFRFUk5TID0gREVGQVVMVF9CTE9DS0VEX1NJVEVTLm1hcCgoZG9tYWluKSA9PiBgKjovLyouJHtkb21haW59LypgKTtcbmNvbnN0IGlzTWFuaWZlc3RWMiA9IHR5cGVvZiBjaHJvbWUud2ViUmVxdWVzdCAhPT0gJ3VuZGVmaW5lZCc7XG5pZiAoaXNNYW5pZmVzdFYyKSB7XG4gICAgY2hyb21lLndlYlJlcXVlc3Qub25CZWZvcmVSZXF1ZXN0LmFkZExpc3RlbmVyKCgpID0+IHtcbiAgICAgICAgY29uc29sZS5sb2coJ1tCbG9ja1NpdGVzXSBCbG9ja2VkIHNpdGUgcmVxdWVzdCcpO1xuICAgICAgICByZXR1cm4geyBjYW5jZWw6IHRydWUgfTtcbiAgICB9LCB7IHVybHM6IEJMT0NLRURfVVJMX1BBVFRFUk5TIH0sIFsnYmxvY2tpbmcnXSk7XG4gICAgY29uc29sZS5sb2coJ1tCbG9ja1NpdGVzXSBXZWJSZXF1ZXN0IGJsb2NrIHJ1bGVzIGluaXRpYWxpemVkIChNYW5pZmVzdCBWMikuJyk7XG59XG5lbHNlIHtcbiAgICBjaHJvbWUucnVudGltZS5vbkluc3RhbGxlZC5hZGRMaXN0ZW5lcigoKSA9PiB7XG4gICAgICAgIGNvbnNvbGUubG9nKCdbQmxvY2tTaXRlc10gRGVjbGFyYXRpdmVOZXRSZXF1ZXN0IHJ1bGVzIGluaXRpYWxpemVkIChNYW5pZmVzdCBWMykuJyk7XG4gICAgfSk7XG59XG4iXSwibmFtZXMiOltdLCJzb3VyY2VSb290IjoiIn0=