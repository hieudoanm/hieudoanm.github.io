/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/*!************************!*\
  !*** ./src/content.ts ***!
  \************************/

// Content script for Block Sites Extension
// Displays a clean block page when a site is blocked
const DEFAULT_BLOCKED_DOMAINS = [
    'facebook.com',
    'twitter.com',
    'reddit.com',
    'tiktok.com',
];
function isBlocked(hostname) {
    return DEFAULT_BLOCKED_DOMAINS.some((domain) => hostname === domain || hostname.endsWith(`.${domain}`));
}
if (isBlocked(window.location.hostname)) {
    document.documentElement.innerHTML = `
    <html>
      <head>
        <title>Site Blocked</title>
        <style>
          * { margin: 0; padding: 0; box-sizing: border-box; }
          body {
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            min-height: 100vh;
            font-family: system-ui, -apple-system, sans-serif;
            background: #0f172a;
            color: #f8fafc;
          }
          .icon { font-size: 4rem; margin-bottom: 1rem; }
          h1 { font-size: 2rem; margin-bottom: 0.5rem; }
          p { color: #94a3b8; font-size: 1rem; }
          .domain {
            margin-top: 0.75rem;
            padding: 0.4rem 1rem;
            background: #1e293b;
            border-radius: 9999px;
            font-family: monospace;
            font-size: 0.9rem;
            color: #ef4444;
          }
        </style>
      </head>
      <body>
        <div class="icon">🚫</div>
        <h1>Site Blocked</h1>
        <p>This website has been blocked by the Block Sites extension.</p>
        <span class="domain">${window.location.hostname}</span>
      </body>
    </html>
  `;
}

/******/ })()
;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiY29udGVudC5qcyIsIm1hcHBpbmdzIjoiOzs7OztBQUFhO0FBQ2I7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsaUdBQWlHLE9BQU87QUFDeEc7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxjQUFjLFdBQVcsWUFBWTtBQUNyQztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGtCQUFrQixpQkFBaUI7QUFDbkMsZUFBZSxpQkFBaUI7QUFDaEMsY0FBYyxnQkFBZ0I7QUFDOUI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsK0JBQStCLHlCQUF5QjtBQUN4RDtBQUNBO0FBQ0E7QUFDQSIsInNvdXJjZXMiOlsid2VicGFjazovL0BibG9jay9zaXRlcy8uL3NyYy9jb250ZW50LnRzIl0sInNvdXJjZXNDb250ZW50IjpbIlwidXNlIHN0cmljdFwiO1xuLy8gQ29udGVudCBzY3JpcHQgZm9yIEJsb2NrIFNpdGVzIEV4dGVuc2lvblxuLy8gRGlzcGxheXMgYSBjbGVhbiBibG9jayBwYWdlIHdoZW4gYSBzaXRlIGlzIGJsb2NrZWRcbmNvbnN0IERFRkFVTFRfQkxPQ0tFRF9ET01BSU5TID0gW1xuICAgICdmYWNlYm9vay5jb20nLFxuICAgICd0d2l0dGVyLmNvbScsXG4gICAgJ3JlZGRpdC5jb20nLFxuICAgICd0aWt0b2suY29tJyxcbl07XG5mdW5jdGlvbiBpc0Jsb2NrZWQoaG9zdG5hbWUpIHtcbiAgICByZXR1cm4gREVGQVVMVF9CTE9DS0VEX0RPTUFJTlMuc29tZSgoZG9tYWluKSA9PiBob3N0bmFtZSA9PT0gZG9tYWluIHx8IGhvc3RuYW1lLmVuZHNXaXRoKGAuJHtkb21haW59YCkpO1xufVxuaWYgKGlzQmxvY2tlZCh3aW5kb3cubG9jYXRpb24uaG9zdG5hbWUpKSB7XG4gICAgZG9jdW1lbnQuZG9jdW1lbnRFbGVtZW50LmlubmVySFRNTCA9IGBcbiAgICA8aHRtbD5cbiAgICAgIDxoZWFkPlxuICAgICAgICA8dGl0bGU+U2l0ZSBCbG9ja2VkPC90aXRsZT5cbiAgICAgICAgPHN0eWxlPlxuICAgICAgICAgICogeyBtYXJnaW46IDA7IHBhZGRpbmc6IDA7IGJveC1zaXppbmc6IGJvcmRlci1ib3g7IH1cbiAgICAgICAgICBib2R5IHtcbiAgICAgICAgICAgIGRpc3BsYXk6IGZsZXg7XG4gICAgICAgICAgICBmbGV4LWRpcmVjdGlvbjogY29sdW1uO1xuICAgICAgICAgICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcbiAgICAgICAgICAgIGp1c3RpZnktY29udGVudDogY2VudGVyO1xuICAgICAgICAgICAgbWluLWhlaWdodDogMTAwdmg7XG4gICAgICAgICAgICBmb250LWZhbWlseTogc3lzdGVtLXVpLCAtYXBwbGUtc3lzdGVtLCBzYW5zLXNlcmlmO1xuICAgICAgICAgICAgYmFja2dyb3VuZDogIzBmMTcyYTtcbiAgICAgICAgICAgIGNvbG9yOiAjZjhmYWZjO1xuICAgICAgICAgIH1cbiAgICAgICAgICAuaWNvbiB7IGZvbnQtc2l6ZTogNHJlbTsgbWFyZ2luLWJvdHRvbTogMXJlbTsgfVxuICAgICAgICAgIGgxIHsgZm9udC1zaXplOiAycmVtOyBtYXJnaW4tYm90dG9tOiAwLjVyZW07IH1cbiAgICAgICAgICBwIHsgY29sb3I6ICM5NGEzYjg7IGZvbnQtc2l6ZTogMXJlbTsgfVxuICAgICAgICAgIC5kb21haW4ge1xuICAgICAgICAgICAgbWFyZ2luLXRvcDogMC43NXJlbTtcbiAgICAgICAgICAgIHBhZGRpbmc6IDAuNHJlbSAxcmVtO1xuICAgICAgICAgICAgYmFja2dyb3VuZDogIzFlMjkzYjtcbiAgICAgICAgICAgIGJvcmRlci1yYWRpdXM6IDk5OTlweDtcbiAgICAgICAgICAgIGZvbnQtZmFtaWx5OiBtb25vc3BhY2U7XG4gICAgICAgICAgICBmb250LXNpemU6IDAuOXJlbTtcbiAgICAgICAgICAgIGNvbG9yOiAjZWY0NDQ0O1xuICAgICAgICAgIH1cbiAgICAgICAgPC9zdHlsZT5cbiAgICAgIDwvaGVhZD5cbiAgICAgIDxib2R5PlxuICAgICAgICA8ZGl2IGNsYXNzPVwiaWNvblwiPvCfmqs8L2Rpdj5cbiAgICAgICAgPGgxPlNpdGUgQmxvY2tlZDwvaDE+XG4gICAgICAgIDxwPlRoaXMgd2Vic2l0ZSBoYXMgYmVlbiBibG9ja2VkIGJ5IHRoZSBCbG9jayBTaXRlcyBleHRlbnNpb24uPC9wPlxuICAgICAgICA8c3BhbiBjbGFzcz1cImRvbWFpblwiPiR7d2luZG93LmxvY2F0aW9uLmhvc3RuYW1lfTwvc3Bhbj5cbiAgICAgIDwvYm9keT5cbiAgICA8L2h0bWw+XG4gIGA7XG59XG4iXSwibmFtZXMiOltdLCJzb3VyY2VSb290IjoiIn0=