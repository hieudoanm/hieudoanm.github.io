/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/*!***************************!*\
  !*** ./src/background.ts ***!
  \***************************/

// Background script for Block Ads and Banners Extension
const isManifestV2 = typeof chrome.webRequest !== 'undefined';
if (isManifestV2) {
    const AD_DOMAINS = [
        '*://*.doubleclick.net/*',
        '*://*.google-analytics.com/*',
        '*://*.googlesyndication.com/*',
        '*://*.adnxs.com/*',
        '*://*.outbrain.com/*',
        '*://*.taboola.com/*',
    ];
    chrome.webRequest.onBeforeRequest.addListener(() => {
        console.log('[AdBlocker] Blocked network ad request');
        return { cancel: true };
    }, { urls: AD_DOMAINS }, ['blocking']);
    console.log('[AdBlocker] WebRequest block rules initialized (Manifest V2).');
}
else {
    chrome.runtime.onInstalled.addListener(() => {
        console.log('[AdBlocker] DeclarativeNetRequest block rules initialized (Manifest V3).');
    });
}

/******/ })()
;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiYmFja2dyb3VuZC5qcyIsIm1hcHBpbmdzIjoiOzs7OztBQUFhO0FBQ2I7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxpQkFBaUI7QUFDakIsS0FBSyxJQUFJLGtCQUFrQjtBQUMzQjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsS0FBSztBQUNMIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vQGJsb2NrL2Fkcy8uL3NyYy9iYWNrZ3JvdW5kLnRzIl0sInNvdXJjZXNDb250ZW50IjpbIlwidXNlIHN0cmljdFwiO1xuLy8gQmFja2dyb3VuZCBzY3JpcHQgZm9yIEJsb2NrIEFkcyBhbmQgQmFubmVycyBFeHRlbnNpb25cbmNvbnN0IGlzTWFuaWZlc3RWMiA9IHR5cGVvZiBjaHJvbWUud2ViUmVxdWVzdCAhPT0gJ3VuZGVmaW5lZCc7XG5pZiAoaXNNYW5pZmVzdFYyKSB7XG4gICAgY29uc3QgQURfRE9NQUlOUyA9IFtcbiAgICAgICAgJyo6Ly8qLmRvdWJsZWNsaWNrLm5ldC8qJyxcbiAgICAgICAgJyo6Ly8qLmdvb2dsZS1hbmFseXRpY3MuY29tLyonLFxuICAgICAgICAnKjovLyouZ29vZ2xlc3luZGljYXRpb24uY29tLyonLFxuICAgICAgICAnKjovLyouYWRueHMuY29tLyonLFxuICAgICAgICAnKjovLyoub3V0YnJhaW4uY29tLyonLFxuICAgICAgICAnKjovLyoudGFib29sYS5jb20vKicsXG4gICAgXTtcbiAgICBjaHJvbWUud2ViUmVxdWVzdC5vbkJlZm9yZVJlcXVlc3QuYWRkTGlzdGVuZXIoKCkgPT4ge1xuICAgICAgICBjb25zb2xlLmxvZygnW0FkQmxvY2tlcl0gQmxvY2tlZCBuZXR3b3JrIGFkIHJlcXVlc3QnKTtcbiAgICAgICAgcmV0dXJuIHsgY2FuY2VsOiB0cnVlIH07XG4gICAgfSwgeyB1cmxzOiBBRF9ET01BSU5TIH0sIFsnYmxvY2tpbmcnXSk7XG4gICAgY29uc29sZS5sb2coJ1tBZEJsb2NrZXJdIFdlYlJlcXVlc3QgYmxvY2sgcnVsZXMgaW5pdGlhbGl6ZWQgKE1hbmlmZXN0IFYyKS4nKTtcbn1cbmVsc2Uge1xuICAgIGNocm9tZS5ydW50aW1lLm9uSW5zdGFsbGVkLmFkZExpc3RlbmVyKCgpID0+IHtcbiAgICAgICAgY29uc29sZS5sb2coJ1tBZEJsb2NrZXJdIERlY2xhcmF0aXZlTmV0UmVxdWVzdCBibG9jayBydWxlcyBpbml0aWFsaXplZCAoTWFuaWZlc3QgVjMpLicpO1xuICAgIH0pO1xufVxuIl0sIm5hbWVzIjpbXSwic291cmNlUm9vdCI6IiJ9