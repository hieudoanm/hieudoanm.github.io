/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/*!************************!*\
  !*** ./src/content.ts ***!
  \************************/

// Content script to hide ad and banner elements dynamically from the DOM
const AD_SELECTORS = [
    '.ads',
    '.adsbox',
    '.ad-placement',
    '.ad-placeholder',
    '.ad-container',
    '.advertisement',
    'ins.adsbygoogle',
    '[class*="ad-"]',
    '[id*="ad-"]',
    '[class*="ads-"]',
    '[id*="ads-"]',
    'a[href*="doubleclick.net"]',
    'iframe[src*="doubleclick.net"]',
    'iframe[src*="googlesyndication"]',
];
function hideAds() {
    const selectorString = AD_SELECTORS.join(', ');
    const elements = document.querySelectorAll(selectorString);
    elements.forEach((el) => {
        const htmlEl = el;
        if (htmlEl.style.display !== 'none') {
            htmlEl.style.setProperty('display', 'none', 'important');
            console.log('[AdBlocker] Hid ad banner element:', el);
        }
    });
}
// Run immediately at document start
hideAds();
// Also run when the DOM content is fully loaded
document.addEventListener('DOMContentLoaded', hideAds);
// Continuous hidden scanning via mutation observer to handle dynamically loaded ads
const observer = new MutationObserver(() => {
    hideAds();
});
// Start observing when body/document element becomes available
const targetNode = document.documentElement || document.body;
if (targetNode) {
    observer.observe(targetNode, {
        childList: true,
        subtree: true,
    });
}
else {
    window.addEventListener('load', () => {
        observer.observe(document.body, {
            childList: true,
            subtree: true,
        });
        hideAds();
    });
}

/******/ })()
;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiY29udGVudC5qcyIsIm1hcHBpbmdzIjoiOzs7OztBQUFhO0FBQ2I7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEtBQUs7QUFDTDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsQ0FBQztBQUNEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEtBQUs7QUFDTDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxTQUFTO0FBQ1Q7QUFDQSxLQUFLO0FBQ0wiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9AYmxvY2svYWRzLy4vc3JjL2NvbnRlbnQudHMiXSwic291cmNlc0NvbnRlbnQiOlsiXCJ1c2Ugc3RyaWN0XCI7XG4vLyBDb250ZW50IHNjcmlwdCB0byBoaWRlIGFkIGFuZCBiYW5uZXIgZWxlbWVudHMgZHluYW1pY2FsbHkgZnJvbSB0aGUgRE9NXG5jb25zdCBBRF9TRUxFQ1RPUlMgPSBbXG4gICAgJy5hZHMnLFxuICAgICcuYWRzYm94JyxcbiAgICAnLmFkLXBsYWNlbWVudCcsXG4gICAgJy5hZC1wbGFjZWhvbGRlcicsXG4gICAgJy5hZC1jb250YWluZXInLFxuICAgICcuYWR2ZXJ0aXNlbWVudCcsXG4gICAgJ2lucy5hZHNieWdvb2dsZScsXG4gICAgJ1tjbGFzcyo9XCJhZC1cIl0nLFxuICAgICdbaWQqPVwiYWQtXCJdJyxcbiAgICAnW2NsYXNzKj1cImFkcy1cIl0nLFxuICAgICdbaWQqPVwiYWRzLVwiXScsXG4gICAgJ2FbaHJlZio9XCJkb3VibGVjbGljay5uZXRcIl0nLFxuICAgICdpZnJhbWVbc3JjKj1cImRvdWJsZWNsaWNrLm5ldFwiXScsXG4gICAgJ2lmcmFtZVtzcmMqPVwiZ29vZ2xlc3luZGljYXRpb25cIl0nLFxuXTtcbmZ1bmN0aW9uIGhpZGVBZHMoKSB7XG4gICAgY29uc3Qgc2VsZWN0b3JTdHJpbmcgPSBBRF9TRUxFQ1RPUlMuam9pbignLCAnKTtcbiAgICBjb25zdCBlbGVtZW50cyA9IGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3JBbGwoc2VsZWN0b3JTdHJpbmcpO1xuICAgIGVsZW1lbnRzLmZvckVhY2goKGVsKSA9PiB7XG4gICAgICAgIGNvbnN0IGh0bWxFbCA9IGVsO1xuICAgICAgICBpZiAoaHRtbEVsLnN0eWxlLmRpc3BsYXkgIT09ICdub25lJykge1xuICAgICAgICAgICAgaHRtbEVsLnN0eWxlLnNldFByb3BlcnR5KCdkaXNwbGF5JywgJ25vbmUnLCAnaW1wb3J0YW50Jyk7XG4gICAgICAgICAgICBjb25zb2xlLmxvZygnW0FkQmxvY2tlcl0gSGlkIGFkIGJhbm5lciBlbGVtZW50OicsIGVsKTtcbiAgICAgICAgfVxuICAgIH0pO1xufVxuLy8gUnVuIGltbWVkaWF0ZWx5IGF0IGRvY3VtZW50IHN0YXJ0XG5oaWRlQWRzKCk7XG4vLyBBbHNvIHJ1biB3aGVuIHRoZSBET00gY29udGVudCBpcyBmdWxseSBsb2FkZWRcbmRvY3VtZW50LmFkZEV2ZW50TGlzdGVuZXIoJ0RPTUNvbnRlbnRMb2FkZWQnLCBoaWRlQWRzKTtcbi8vIENvbnRpbnVvdXMgaGlkZGVuIHNjYW5uaW5nIHZpYSBtdXRhdGlvbiBvYnNlcnZlciB0byBoYW5kbGUgZHluYW1pY2FsbHkgbG9hZGVkIGFkc1xuY29uc3Qgb2JzZXJ2ZXIgPSBuZXcgTXV0YXRpb25PYnNlcnZlcigoKSA9PiB7XG4gICAgaGlkZUFkcygpO1xufSk7XG4vLyBTdGFydCBvYnNlcnZpbmcgd2hlbiBib2R5L2RvY3VtZW50IGVsZW1lbnQgYmVjb21lcyBhdmFpbGFibGVcbmNvbnN0IHRhcmdldE5vZGUgPSBkb2N1bWVudC5kb2N1bWVudEVsZW1lbnQgfHwgZG9jdW1lbnQuYm9keTtcbmlmICh0YXJnZXROb2RlKSB7XG4gICAgb2JzZXJ2ZXIub2JzZXJ2ZSh0YXJnZXROb2RlLCB7XG4gICAgICAgIGNoaWxkTGlzdDogdHJ1ZSxcbiAgICAgICAgc3VidHJlZTogdHJ1ZSxcbiAgICB9KTtcbn1cbmVsc2Uge1xuICAgIHdpbmRvdy5hZGRFdmVudExpc3RlbmVyKCdsb2FkJywgKCkgPT4ge1xuICAgICAgICBvYnNlcnZlci5vYnNlcnZlKGRvY3VtZW50LmJvZHksIHtcbiAgICAgICAgICAgIGNoaWxkTGlzdDogdHJ1ZSxcbiAgICAgICAgICAgIHN1YnRyZWU6IHRydWUsXG4gICAgICAgIH0pO1xuICAgICAgICBoaWRlQWRzKCk7XG4gICAgfSk7XG59XG4iXSwibmFtZXMiOltdLCJzb3VyY2VSb290IjoiIn0=