/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	var __webpack_modules__ = ({

/***/ "./src/popup.ts"
/*!**********************!*\
  !*** ./src/popup.ts ***!
  \**********************/
() {


// popup.js
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
const captureBtn = document.getElementById('captureBtn');
const downloadBtn = document.getElementById('downloadBtn');
const copyBtn = document.getElementById('copyBtn');
const previewWrap = document.getElementById('previewWrap');
const previewImg = document.getElementById('previewImg');
const previewSize = document.getElementById('previewSize');
const statusEl = document.getElementById('status');
const autoDownload = document.getElementById('autoDownload');
const formatSelect = document.getElementById('formatSelect');
const tabUrlEl = document.getElementById('tabUrl');
let lastDataUrl = null;
let lastFilename = null;
// Show current tab URL
chrome.tabs.query({ active: true, currentWindow: true }, ([tab]) => {
    if (!tabUrlEl)
        return;
    if (tab === null || tab === void 0 ? void 0 : tab.url) {
        try {
            const url = new URL(tab.url);
            tabUrlEl.innerHTML = `<span>${url.hostname}</span>${url.pathname === '/' ? '' : url.pathname}`;
        }
        catch (_a) {
            tabUrlEl.innerHTML = `<span>${tab.url}</span>`;
        }
    }
});
function setStatus(msg, type = '') {
    if (!statusEl)
        return;
    statusEl.textContent = msg;
    statusEl.className = 'status' + (type ? ` ${type}` : '');
}
function bytesToSize(base64) {
    const bytes = Math.round((base64.length * 3) / 4);
    if (bytes < 1024)
        return `${bytes} B`;
    if (bytes < 1048576)
        return `${(bytes / 1024).toFixed(1)} KB`;
    return `${(bytes / 1048576).toFixed(1)} MB`;
}
function getTimestamp() {
    const now = new Date();
    return now.toISOString().replace(/[:.]/g, '-').replace('T', '_').slice(0, 19);
}
function captureTab() {
    return __awaiter(this, void 0, void 0, function* () {
        if (!formatSelect)
            return;
        const format = formatSelect.value;
        const mimeType = format === 'jpeg'
            ? 'image/jpeg'
            : format === 'webp'
                ? 'image/webp'
                : 'image/png';
        const quality = format === 'png' ? undefined : 92;
        captureBtn === null || captureBtn === void 0 ? void 0 : captureBtn.classList.add('loading');
        setStatus('Capturing...');
        previewWrap === null || previewWrap === void 0 ? void 0 : previewWrap.classList.remove('visible');
        lastDataUrl = null;
        try {
            const [tab] = yield chrome.tabs.query({
                active: true,
                currentWindow: true,
            });
            if (!tab)
                throw new Error('No active tab found.');
            // Use captureVisibleTab from background script (avoids popup focus issues)
            const dataUrl = yield chrome.runtime.sendMessage({
                action: 'captureTab',
                format,
                quality,
                mimeType,
            });
            if (!dataUrl || dataUrl.startsWith('ERROR:')) {
                throw new Error((dataUrl === null || dataUrl === void 0 ? void 0 : dataUrl.replace('ERROR:', '')) || 'Capture failed.');
            }
            lastDataUrl = dataUrl;
            lastFilename = `snapshot_${getTimestamp()}.${format}`;
            // Show preview
            previewImg.src = dataUrl;
            previewSize.textContent = bytesToSize(dataUrl);
            previewWrap.classList.add('visible');
            setStatus('Captured successfully', 'ok');
            if (autoDownload === null || autoDownload === void 0 ? void 0 : autoDownload.checked) {
                triggerDownload(dataUrl, lastFilename);
            }
        }
        catch (err) {
            setStatus(err.message || 'Capture failed.', 'err');
        }
        finally {
            captureBtn.classList.remove('loading');
        }
    });
}
function triggerDownload(dataUrl, filename) {
    chrome.downloads.download({ url: dataUrl, filename, saveAs: false }, (id) => {
        console.log(id);
        if (chrome.runtime.lastError) {
            setStatus('Download error: ' + chrome.runtime.lastError.message, 'err');
        }
        else {
            setStatus('Saved to downloads ✓', 'ok');
        }
    });
}
downloadBtn.addEventListener('click', () => {
    if (!lastDataUrl)
        return;
    triggerDownload(lastDataUrl, lastFilename !== null && lastFilename !== void 0 ? lastFilename : '');
});
copyBtn.addEventListener('click', () => __awaiter(void 0, void 0, void 0, function* () {
    if (!lastDataUrl)
        return;
    try {
        // Convert data URL to blob and copy to clipboard
        const res = yield fetch(lastDataUrl);
        const blob = yield res.blob();
        yield navigator.clipboard.write([new ClipboardItem({ [blob.type]: blob })]);
        setStatus('Copied to clipboard ✓', 'ok');
    }
    catch (_a) {
        setStatus('Copy not supported in this context.', 'err');
    }
}));
captureBtn.addEventListener('click', captureTab);


/***/ }

/******/ 	});
/************************************************************************/
/******/ 	
/******/ 	// startup
/******/ 	// Load entry module and return exports
/******/ 	// This entry module is referenced by other modules so it can't be inlined
/******/ 	var __webpack_exports__ = {};
/******/ 	__webpack_modules__["./src/popup.ts"].call(__webpack_exports__);
/******/ 	
/******/ })()
;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicG9wdXAuanMiLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7OztBQUFhO0FBQ2I7QUFDQTtBQUNBLDRCQUE0QiwrREFBK0QsaUJBQWlCO0FBQzVHO0FBQ0Esb0NBQW9DLE1BQU0sK0JBQStCLFlBQVk7QUFDckYsbUNBQW1DLE1BQU0sbUNBQW1DLFlBQVk7QUFDeEYsZ0NBQWdDO0FBQ2hDO0FBQ0EsS0FBSztBQUNMO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxvQkFBb0IsbUNBQW1DO0FBQ3ZEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSwwQ0FBMEMsYUFBYSxTQUFTLHlDQUF5QztBQUN6RztBQUNBO0FBQ0EsMENBQTBDLFFBQVE7QUFDbEQ7QUFDQTtBQUNBLENBQUM7QUFDRDtBQUNBO0FBQ0E7QUFDQTtBQUNBLGdEQUFnRCxLQUFLO0FBQ3JEO0FBQ0E7QUFDQTtBQUNBO0FBQ0Esa0JBQWtCLE9BQU87QUFDekI7QUFDQSxrQkFBa0IsMkJBQTJCO0FBQzdDLGNBQWMsOEJBQThCO0FBQzVDO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGFBQWE7QUFDYjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsYUFBYTtBQUNiO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsdUNBQXVDLGVBQWUsR0FBRyxPQUFPO0FBQ2hFO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEtBQUs7QUFDTDtBQUNBO0FBQ0EsZ0NBQWdDLHVDQUF1QztBQUN2RTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEtBQUs7QUFDTDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsQ0FBQztBQUNEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsNkRBQTZELG1CQUFtQjtBQUNoRjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsQ0FBQztBQUNEOzs7Ozs7OztVRXhJQTtVQUNBO1VBQ0E7VUFDQTtVQUNBIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vQHRhYi9zbmFwc2hvdC8uL3NyYy9wb3B1cC50cyIsIndlYnBhY2s6Ly9AdGFiL3NuYXBzaG90L3dlYnBhY2svYmVmb3JlLXN0YXJ0dXAiLCJ3ZWJwYWNrOi8vQHRhYi9zbmFwc2hvdC93ZWJwYWNrL3N0YXJ0dXAiLCJ3ZWJwYWNrOi8vQHRhYi9zbmFwc2hvdC93ZWJwYWNrL2FmdGVyLXN0YXJ0dXAiXSwic291cmNlc0NvbnRlbnQiOlsiXCJ1c2Ugc3RyaWN0XCI7XG4vLyBwb3B1cC5qc1xudmFyIF9fYXdhaXRlciA9ICh0aGlzICYmIHRoaXMuX19hd2FpdGVyKSB8fCBmdW5jdGlvbiAodGhpc0FyZywgX2FyZ3VtZW50cywgUCwgZ2VuZXJhdG9yKSB7XG4gICAgZnVuY3Rpb24gYWRvcHQodmFsdWUpIHsgcmV0dXJuIHZhbHVlIGluc3RhbmNlb2YgUCA/IHZhbHVlIDogbmV3IFAoZnVuY3Rpb24gKHJlc29sdmUpIHsgcmVzb2x2ZSh2YWx1ZSk7IH0pOyB9XG4gICAgcmV0dXJuIG5ldyAoUCB8fCAoUCA9IFByb21pc2UpKShmdW5jdGlvbiAocmVzb2x2ZSwgcmVqZWN0KSB7XG4gICAgICAgIGZ1bmN0aW9uIGZ1bGZpbGxlZCh2YWx1ZSkgeyB0cnkgeyBzdGVwKGdlbmVyYXRvci5uZXh0KHZhbHVlKSk7IH0gY2F0Y2ggKGUpIHsgcmVqZWN0KGUpOyB9IH1cbiAgICAgICAgZnVuY3Rpb24gcmVqZWN0ZWQodmFsdWUpIHsgdHJ5IHsgc3RlcChnZW5lcmF0b3JbXCJ0aHJvd1wiXSh2YWx1ZSkpOyB9IGNhdGNoIChlKSB7IHJlamVjdChlKTsgfSB9XG4gICAgICAgIGZ1bmN0aW9uIHN0ZXAocmVzdWx0KSB7IHJlc3VsdC5kb25lID8gcmVzb2x2ZShyZXN1bHQudmFsdWUpIDogYWRvcHQocmVzdWx0LnZhbHVlKS50aGVuKGZ1bGZpbGxlZCwgcmVqZWN0ZWQpOyB9XG4gICAgICAgIHN0ZXAoKGdlbmVyYXRvciA9IGdlbmVyYXRvci5hcHBseSh0aGlzQXJnLCBfYXJndW1lbnRzIHx8IFtdKSkubmV4dCgpKTtcbiAgICB9KTtcbn07XG5jb25zdCBjYXB0dXJlQnRuID0gZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoJ2NhcHR1cmVCdG4nKTtcbmNvbnN0IGRvd25sb2FkQnRuID0gZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoJ2Rvd25sb2FkQnRuJyk7XG5jb25zdCBjb3B5QnRuID0gZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoJ2NvcHlCdG4nKTtcbmNvbnN0IHByZXZpZXdXcmFwID0gZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoJ3ByZXZpZXdXcmFwJyk7XG5jb25zdCBwcmV2aWV3SW1nID0gZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoJ3ByZXZpZXdJbWcnKTtcbmNvbnN0IHByZXZpZXdTaXplID0gZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoJ3ByZXZpZXdTaXplJyk7XG5jb25zdCBzdGF0dXNFbCA9IGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKCdzdGF0dXMnKTtcbmNvbnN0IGF1dG9Eb3dubG9hZCA9IGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKCdhdXRvRG93bmxvYWQnKTtcbmNvbnN0IGZvcm1hdFNlbGVjdCA9IGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKCdmb3JtYXRTZWxlY3QnKTtcbmNvbnN0IHRhYlVybEVsID0gZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoJ3RhYlVybCcpO1xubGV0IGxhc3REYXRhVXJsID0gbnVsbDtcbmxldCBsYXN0RmlsZW5hbWUgPSBudWxsO1xuLy8gU2hvdyBjdXJyZW50IHRhYiBVUkxcbmNocm9tZS50YWJzLnF1ZXJ5KHsgYWN0aXZlOiB0cnVlLCBjdXJyZW50V2luZG93OiB0cnVlIH0sIChbdGFiXSkgPT4ge1xuICAgIGlmICghdGFiVXJsRWwpXG4gICAgICAgIHJldHVybjtcbiAgICBpZiAodGFiID09PSBudWxsIHx8IHRhYiA9PT0gdm9pZCAwID8gdm9pZCAwIDogdGFiLnVybCkge1xuICAgICAgICB0cnkge1xuICAgICAgICAgICAgY29uc3QgdXJsID0gbmV3IFVSTCh0YWIudXJsKTtcbiAgICAgICAgICAgIHRhYlVybEVsLmlubmVySFRNTCA9IGA8c3Bhbj4ke3VybC5ob3N0bmFtZX08L3NwYW4+JHt1cmwucGF0aG5hbWUgPT09ICcvJyA/ICcnIDogdXJsLnBhdGhuYW1lfWA7XG4gICAgICAgIH1cbiAgICAgICAgY2F0Y2ggKF9hKSB7XG4gICAgICAgICAgICB0YWJVcmxFbC5pbm5lckhUTUwgPSBgPHNwYW4+JHt0YWIudXJsfTwvc3Bhbj5gO1xuICAgICAgICB9XG4gICAgfVxufSk7XG5mdW5jdGlvbiBzZXRTdGF0dXMobXNnLCB0eXBlID0gJycpIHtcbiAgICBpZiAoIXN0YXR1c0VsKVxuICAgICAgICByZXR1cm47XG4gICAgc3RhdHVzRWwudGV4dENvbnRlbnQgPSBtc2c7XG4gICAgc3RhdHVzRWwuY2xhc3NOYW1lID0gJ3N0YXR1cycgKyAodHlwZSA/IGAgJHt0eXBlfWAgOiAnJyk7XG59XG5mdW5jdGlvbiBieXRlc1RvU2l6ZShiYXNlNjQpIHtcbiAgICBjb25zdCBieXRlcyA9IE1hdGgucm91bmQoKGJhc2U2NC5sZW5ndGggKiAzKSAvIDQpO1xuICAgIGlmIChieXRlcyA8IDEwMjQpXG4gICAgICAgIHJldHVybiBgJHtieXRlc30gQmA7XG4gICAgaWYgKGJ5dGVzIDwgMTA0ODU3NilcbiAgICAgICAgcmV0dXJuIGAkeyhieXRlcyAvIDEwMjQpLnRvRml4ZWQoMSl9IEtCYDtcbiAgICByZXR1cm4gYCR7KGJ5dGVzIC8gMTA0ODU3NikudG9GaXhlZCgxKX0gTUJgO1xufVxuZnVuY3Rpb24gZ2V0VGltZXN0YW1wKCkge1xuICAgIGNvbnN0IG5vdyA9IG5ldyBEYXRlKCk7XG4gICAgcmV0dXJuIG5vdy50b0lTT1N0cmluZygpLnJlcGxhY2UoL1s6Ll0vZywgJy0nKS5yZXBsYWNlKCdUJywgJ18nKS5zbGljZSgwLCAxOSk7XG59XG5mdW5jdGlvbiBjYXB0dXJlVGFiKCkge1xuICAgIHJldHVybiBfX2F3YWl0ZXIodGhpcywgdm9pZCAwLCB2b2lkIDAsIGZ1bmN0aW9uKiAoKSB7XG4gICAgICAgIGlmICghZm9ybWF0U2VsZWN0KVxuICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICBjb25zdCBmb3JtYXQgPSBmb3JtYXRTZWxlY3QudmFsdWU7XG4gICAgICAgIGNvbnN0IG1pbWVUeXBlID0gZm9ybWF0ID09PSAnanBlZydcbiAgICAgICAgICAgID8gJ2ltYWdlL2pwZWcnXG4gICAgICAgICAgICA6IGZvcm1hdCA9PT0gJ3dlYnAnXG4gICAgICAgICAgICAgICAgPyAnaW1hZ2Uvd2VicCdcbiAgICAgICAgICAgICAgICA6ICdpbWFnZS9wbmcnO1xuICAgICAgICBjb25zdCBxdWFsaXR5ID0gZm9ybWF0ID09PSAncG5nJyA/IHVuZGVmaW5lZCA6IDkyO1xuICAgICAgICBjYXB0dXJlQnRuID09PSBudWxsIHx8IGNhcHR1cmVCdG4gPT09IHZvaWQgMCA/IHZvaWQgMCA6IGNhcHR1cmVCdG4uY2xhc3NMaXN0LmFkZCgnbG9hZGluZycpO1xuICAgICAgICBzZXRTdGF0dXMoJ0NhcHR1cmluZy4uLicpO1xuICAgICAgICBwcmV2aWV3V3JhcCA9PT0gbnVsbCB8fCBwcmV2aWV3V3JhcCA9PT0gdm9pZCAwID8gdm9pZCAwIDogcHJldmlld1dyYXAuY2xhc3NMaXN0LnJlbW92ZSgndmlzaWJsZScpO1xuICAgICAgICBsYXN0RGF0YVVybCA9IG51bGw7XG4gICAgICAgIHRyeSB7XG4gICAgICAgICAgICBjb25zdCBbdGFiXSA9IHlpZWxkIGNocm9tZS50YWJzLnF1ZXJ5KHtcbiAgICAgICAgICAgICAgICBhY3RpdmU6IHRydWUsXG4gICAgICAgICAgICAgICAgY3VycmVudFdpbmRvdzogdHJ1ZSxcbiAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgaWYgKCF0YWIpXG4gICAgICAgICAgICAgICAgdGhyb3cgbmV3IEVycm9yKCdObyBhY3RpdmUgdGFiIGZvdW5kLicpO1xuICAgICAgICAgICAgLy8gVXNlIGNhcHR1cmVWaXNpYmxlVGFiIGZyb20gYmFja2dyb3VuZCBzY3JpcHQgKGF2b2lkcyBwb3B1cCBmb2N1cyBpc3N1ZXMpXG4gICAgICAgICAgICBjb25zdCBkYXRhVXJsID0geWllbGQgY2hyb21lLnJ1bnRpbWUuc2VuZE1lc3NhZ2Uoe1xuICAgICAgICAgICAgICAgIGFjdGlvbjogJ2NhcHR1cmVUYWInLFxuICAgICAgICAgICAgICAgIGZvcm1hdCxcbiAgICAgICAgICAgICAgICBxdWFsaXR5LFxuICAgICAgICAgICAgICAgIG1pbWVUeXBlLFxuICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICBpZiAoIWRhdGFVcmwgfHwgZGF0YVVybC5zdGFydHNXaXRoKCdFUlJPUjonKSkge1xuICAgICAgICAgICAgICAgIHRocm93IG5ldyBFcnJvcigoZGF0YVVybCA9PT0gbnVsbCB8fCBkYXRhVXJsID09PSB2b2lkIDAgPyB2b2lkIDAgOiBkYXRhVXJsLnJlcGxhY2UoJ0VSUk9SOicsICcnKSkgfHwgJ0NhcHR1cmUgZmFpbGVkLicpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgbGFzdERhdGFVcmwgPSBkYXRhVXJsO1xuICAgICAgICAgICAgbGFzdEZpbGVuYW1lID0gYHNuYXBzaG90XyR7Z2V0VGltZXN0YW1wKCl9LiR7Zm9ybWF0fWA7XG4gICAgICAgICAgICAvLyBTaG93IHByZXZpZXdcbiAgICAgICAgICAgIHByZXZpZXdJbWcuc3JjID0gZGF0YVVybDtcbiAgICAgICAgICAgIHByZXZpZXdTaXplLnRleHRDb250ZW50ID0gYnl0ZXNUb1NpemUoZGF0YVVybCk7XG4gICAgICAgICAgICBwcmV2aWV3V3JhcC5jbGFzc0xpc3QuYWRkKCd2aXNpYmxlJyk7XG4gICAgICAgICAgICBzZXRTdGF0dXMoJ0NhcHR1cmVkIHN1Y2Nlc3NmdWxseScsICdvaycpO1xuICAgICAgICAgICAgaWYgKGF1dG9Eb3dubG9hZCA9PT0gbnVsbCB8fCBhdXRvRG93bmxvYWQgPT09IHZvaWQgMCA/IHZvaWQgMCA6IGF1dG9Eb3dubG9hZC5jaGVja2VkKSB7XG4gICAgICAgICAgICAgICAgdHJpZ2dlckRvd25sb2FkKGRhdGFVcmwsIGxhc3RGaWxlbmFtZSk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgY2F0Y2ggKGVycikge1xuICAgICAgICAgICAgc2V0U3RhdHVzKGVyci5tZXNzYWdlIHx8ICdDYXB0dXJlIGZhaWxlZC4nLCAnZXJyJyk7XG4gICAgICAgIH1cbiAgICAgICAgZmluYWxseSB7XG4gICAgICAgICAgICBjYXB0dXJlQnRuLmNsYXNzTGlzdC5yZW1vdmUoJ2xvYWRpbmcnKTtcbiAgICAgICAgfVxuICAgIH0pO1xufVxuZnVuY3Rpb24gdHJpZ2dlckRvd25sb2FkKGRhdGFVcmwsIGZpbGVuYW1lKSB7XG4gICAgY2hyb21lLmRvd25sb2Fkcy5kb3dubG9hZCh7IHVybDogZGF0YVVybCwgZmlsZW5hbWUsIHNhdmVBczogZmFsc2UgfSwgKGlkKSA9PiB7XG4gICAgICAgIGNvbnNvbGUubG9nKGlkKTtcbiAgICAgICAgaWYgKGNocm9tZS5ydW50aW1lLmxhc3RFcnJvcikge1xuICAgICAgICAgICAgc2V0U3RhdHVzKCdEb3dubG9hZCBlcnJvcjogJyArIGNocm9tZS5ydW50aW1lLmxhc3RFcnJvci5tZXNzYWdlLCAnZXJyJyk7XG4gICAgICAgIH1cbiAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICBzZXRTdGF0dXMoJ1NhdmVkIHRvIGRvd25sb2FkcyDinJMnLCAnb2snKTtcbiAgICAgICAgfVxuICAgIH0pO1xufVxuZG93bmxvYWRCdG4uYWRkRXZlbnRMaXN0ZW5lcignY2xpY2snLCAoKSA9PiB7XG4gICAgaWYgKCFsYXN0RGF0YVVybClcbiAgICAgICAgcmV0dXJuO1xuICAgIHRyaWdnZXJEb3dubG9hZChsYXN0RGF0YVVybCwgbGFzdEZpbGVuYW1lICE9PSBudWxsICYmIGxhc3RGaWxlbmFtZSAhPT0gdm9pZCAwID8gbGFzdEZpbGVuYW1lIDogJycpO1xufSk7XG5jb3B5QnRuLmFkZEV2ZW50TGlzdGVuZXIoJ2NsaWNrJywgKCkgPT4gX19hd2FpdGVyKHZvaWQgMCwgdm9pZCAwLCB2b2lkIDAsIGZ1bmN0aW9uKiAoKSB7XG4gICAgaWYgKCFsYXN0RGF0YVVybClcbiAgICAgICAgcmV0dXJuO1xuICAgIHRyeSB7XG4gICAgICAgIC8vIENvbnZlcnQgZGF0YSBVUkwgdG8gYmxvYiBhbmQgY29weSB0byBjbGlwYm9hcmRcbiAgICAgICAgY29uc3QgcmVzID0geWllbGQgZmV0Y2gobGFzdERhdGFVcmwpO1xuICAgICAgICBjb25zdCBibG9iID0geWllbGQgcmVzLmJsb2IoKTtcbiAgICAgICAgeWllbGQgbmF2aWdhdG9yLmNsaXBib2FyZC53cml0ZShbbmV3IENsaXBib2FyZEl0ZW0oeyBbYmxvYi50eXBlXTogYmxvYiB9KV0pO1xuICAgICAgICBzZXRTdGF0dXMoJ0NvcGllZCB0byBjbGlwYm9hcmQg4pyTJywgJ29rJyk7XG4gICAgfVxuICAgIGNhdGNoIChfYSkge1xuICAgICAgICBzZXRTdGF0dXMoJ0NvcHkgbm90IHN1cHBvcnRlZCBpbiB0aGlzIGNvbnRleHQuJywgJ2VycicpO1xuICAgIH1cbn0pKTtcbmNhcHR1cmVCdG4uYWRkRXZlbnRMaXN0ZW5lcignY2xpY2snLCBjYXB0dXJlVGFiKTtcbiIsIiIsIi8vIHN0YXJ0dXBcbi8vIExvYWQgZW50cnkgbW9kdWxlIGFuZCByZXR1cm4gZXhwb3J0c1xuLy8gVGhpcyBlbnRyeSBtb2R1bGUgaXMgcmVmZXJlbmNlZCBieSBvdGhlciBtb2R1bGVzIHNvIGl0IGNhbid0IGJlIGlubGluZWRcbnZhciBfX3dlYnBhY2tfZXhwb3J0c19fID0ge307XG5fX3dlYnBhY2tfbW9kdWxlc19fW1wiLi9zcmMvcG9wdXAudHNcIl0uY2FsbChfX3dlYnBhY2tfZXhwb3J0c19fKTtcbiIsIiJdLCJuYW1lcyI6W10sInNvdXJjZVJvb3QiOiIifQ==