/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/*!***************************!*\
  !*** ./src/background.ts ***!
  \***************************/

const BLOCKED_SITES = [
    'facebook.com',
    'twitter.com',
    'instagram.com',
    'youtube.com/shorts',
    'tiktok.com',
];
// Sites where we inject a content script to hide sections instead of blocking
const HIDE_SECTIONS = [
    {
        match: 'youtube.com',
        selector: [
            'ytd-rich-section-renderer', // Shorts shelf on home
            'ytd-reel-shelf-renderer', // Shorts shelf (alt)
            'a[href^="/shorts"]', // Shorts links in sidebar/nav
        ].join(', '),
    },
];
/** Helper: Check full URL (hostname + path) against a site pattern */
function matchesSite(url, site) {
    try {
        const parsed = new URL(url);
        const full = parsed.hostname + parsed.pathname;
        return full.includes(site);
    }
    catch (_a) {
        return false;
    }
}
/** Helper: Check if URL should be fully blocked */
function isBlocked(url) {
    return BLOCKED_SITES.some((site) => matchesSite(url, site));
}
/** Helper: Return hide-section config if URL matches, else null */
function getHideConfig(url) {
    try {
        const hostname = new URL(url).hostname;
        const config = HIDE_SECTIONS.find((s) => hostname.includes(s.match));
        return config ? { selector: config.selector } : null;
    }
    catch (_a) {
        return null;
    }
}
console.log('[Focus] Background script loaded');
// Intercept and redirect fully blocked sites
browser.webRequest.onBeforeRequest.addListener((details) => {
    console.log('[Focus] Intercepted request:', details.url);
    if (isBlocked(details.url)) {
        try {
            const blockedPage = browser.runtime.getURL('blocked.html');
            console.log('[Focus] Blocking tab', details.tabId, '->', blockedPage);
            browser.tabs.update(details.tabId, { url: blockedPage });
            return { cancel: true };
        }
        catch (error) {
            console.error('[Focus] Redirect error:', error);
        }
    }
    else {
        console.log('[Focus] URL not blocked:', details.url);
    }
}, { urls: ['<all_urls>'], types: ['main_frame'] }, ['blocking']);
// Inject content script to hide sections on allowed-but-restricted sites
browser.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
    if (changeInfo.status !== 'complete' || !tab.url)
        return;
    const hideConfig = getHideConfig(tab.url);
    if (!hideConfig)
        return;
    const { selector } = hideConfig;
    browser.tabs.executeScript(tabId, {
        code: `
        (function () {
          const SELECTOR = ${JSON.stringify(selector)};

          function hideElements() {
            document.querySelectorAll(SELECTOR).forEach((el) => {
              el.style.setProperty('display', 'none', 'important');
            });
          }

          // Run immediately on load
          hideElements();

          // Watch for dynamically injected elements (YouTube is an SPA)
          const observer = new MutationObserver(hideElements);
          observer.observe(document.body, { childList: true, subtree: true });
        })();
      `,
    });
});

/******/ })()
;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiYmFja2dyb3VuZC5qcyIsIm1hcHBpbmdzIjoiOzs7OztBQUFhO0FBQ2I7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxLQUFLO0FBQ0w7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsMEJBQTBCLDRCQUE0QjtBQUN0RDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGlEQUFpRCxrQkFBa0I7QUFDbkUscUJBQXFCO0FBQ3JCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxDQUFDLElBQUksNkNBQTZDO0FBQ2xEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsWUFBWSxXQUFXO0FBQ3ZCO0FBQ0E7QUFDQTtBQUNBLDZCQUE2Qjs7QUFFN0I7QUFDQTtBQUNBO0FBQ0EsYUFBYTtBQUNiOztBQUVBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBLDRDQUE0QyxnQ0FBZ0M7QUFDNUUsU0FBUztBQUNUO0FBQ0EsS0FBSztBQUNMLENBQUMiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9AdGFiL2Jsb2NrZWQvLi9zcmMvYmFja2dyb3VuZC50cyJdLCJzb3VyY2VzQ29udGVudCI6WyJcInVzZSBzdHJpY3RcIjtcbmNvbnN0IEJMT0NLRURfU0lURVMgPSBbXG4gICAgJ2ZhY2Vib29rLmNvbScsXG4gICAgJ3R3aXR0ZXIuY29tJyxcbiAgICAnaW5zdGFncmFtLmNvbScsXG4gICAgJ3lvdXR1YmUuY29tL3Nob3J0cycsXG4gICAgJ3Rpa3Rvay5jb20nLFxuXTtcbi8vIFNpdGVzIHdoZXJlIHdlIGluamVjdCBhIGNvbnRlbnQgc2NyaXB0IHRvIGhpZGUgc2VjdGlvbnMgaW5zdGVhZCBvZiBibG9ja2luZ1xuY29uc3QgSElERV9TRUNUSU9OUyA9IFtcbiAgICB7XG4gICAgICAgIG1hdGNoOiAneW91dHViZS5jb20nLFxuICAgICAgICBzZWxlY3RvcjogW1xuICAgICAgICAgICAgJ3l0ZC1yaWNoLXNlY3Rpb24tcmVuZGVyZXInLCAvLyBTaG9ydHMgc2hlbGYgb24gaG9tZVxuICAgICAgICAgICAgJ3l0ZC1yZWVsLXNoZWxmLXJlbmRlcmVyJywgLy8gU2hvcnRzIHNoZWxmIChhbHQpXG4gICAgICAgICAgICAnYVtocmVmXj1cIi9zaG9ydHNcIl0nLCAvLyBTaG9ydHMgbGlua3MgaW4gc2lkZWJhci9uYXZcbiAgICAgICAgXS5qb2luKCcsICcpLFxuICAgIH0sXG5dO1xuLyoqIEhlbHBlcjogQ2hlY2sgZnVsbCBVUkwgKGhvc3RuYW1lICsgcGF0aCkgYWdhaW5zdCBhIHNpdGUgcGF0dGVybiAqL1xuZnVuY3Rpb24gbWF0Y2hlc1NpdGUodXJsLCBzaXRlKSB7XG4gICAgdHJ5IHtcbiAgICAgICAgY29uc3QgcGFyc2VkID0gbmV3IFVSTCh1cmwpO1xuICAgICAgICBjb25zdCBmdWxsID0gcGFyc2VkLmhvc3RuYW1lICsgcGFyc2VkLnBhdGhuYW1lO1xuICAgICAgICByZXR1cm4gZnVsbC5pbmNsdWRlcyhzaXRlKTtcbiAgICB9XG4gICAgY2F0Y2ggKF9hKSB7XG4gICAgICAgIHJldHVybiBmYWxzZTtcbiAgICB9XG59XG4vKiogSGVscGVyOiBDaGVjayBpZiBVUkwgc2hvdWxkIGJlIGZ1bGx5IGJsb2NrZWQgKi9cbmZ1bmN0aW9uIGlzQmxvY2tlZCh1cmwpIHtcbiAgICByZXR1cm4gQkxPQ0tFRF9TSVRFUy5zb21lKChzaXRlKSA9PiBtYXRjaGVzU2l0ZSh1cmwsIHNpdGUpKTtcbn1cbi8qKiBIZWxwZXI6IFJldHVybiBoaWRlLXNlY3Rpb24gY29uZmlnIGlmIFVSTCBtYXRjaGVzLCBlbHNlIG51bGwgKi9cbmZ1bmN0aW9uIGdldEhpZGVDb25maWcodXJsKSB7XG4gICAgdHJ5IHtcbiAgICAgICAgY29uc3QgaG9zdG5hbWUgPSBuZXcgVVJMKHVybCkuaG9zdG5hbWU7XG4gICAgICAgIGNvbnN0IGNvbmZpZyA9IEhJREVfU0VDVElPTlMuZmluZCgocykgPT4gaG9zdG5hbWUuaW5jbHVkZXMocy5tYXRjaCkpO1xuICAgICAgICByZXR1cm4gY29uZmlnID8geyBzZWxlY3RvcjogY29uZmlnLnNlbGVjdG9yIH0gOiBudWxsO1xuICAgIH1cbiAgICBjYXRjaCAoX2EpIHtcbiAgICAgICAgcmV0dXJuIG51bGw7XG4gICAgfVxufVxuY29uc29sZS5sb2coJ1tGb2N1c10gQmFja2dyb3VuZCBzY3JpcHQgbG9hZGVkJyk7XG4vLyBJbnRlcmNlcHQgYW5kIHJlZGlyZWN0IGZ1bGx5IGJsb2NrZWQgc2l0ZXNcbmJyb3dzZXIud2ViUmVxdWVzdC5vbkJlZm9yZVJlcXVlc3QuYWRkTGlzdGVuZXIoKGRldGFpbHMpID0+IHtcbiAgICBjb25zb2xlLmxvZygnW0ZvY3VzXSBJbnRlcmNlcHRlZCByZXF1ZXN0OicsIGRldGFpbHMudXJsKTtcbiAgICBpZiAoaXNCbG9ja2VkKGRldGFpbHMudXJsKSkge1xuICAgICAgICB0cnkge1xuICAgICAgICAgICAgY29uc3QgYmxvY2tlZFBhZ2UgPSBicm93c2VyLnJ1bnRpbWUuZ2V0VVJMKCdibG9ja2VkLmh0bWwnKTtcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKCdbRm9jdXNdIEJsb2NraW5nIHRhYicsIGRldGFpbHMudGFiSWQsICctPicsIGJsb2NrZWRQYWdlKTtcbiAgICAgICAgICAgIGJyb3dzZXIudGFicy51cGRhdGUoZGV0YWlscy50YWJJZCwgeyB1cmw6IGJsb2NrZWRQYWdlIH0pO1xuICAgICAgICAgICAgcmV0dXJuIHsgY2FuY2VsOiB0cnVlIH07XG4gICAgICAgIH1cbiAgICAgICAgY2F0Y2ggKGVycm9yKSB7XG4gICAgICAgICAgICBjb25zb2xlLmVycm9yKCdbRm9jdXNdIFJlZGlyZWN0IGVycm9yOicsIGVycm9yKTtcbiAgICAgICAgfVxuICAgIH1cbiAgICBlbHNlIHtcbiAgICAgICAgY29uc29sZS5sb2coJ1tGb2N1c10gVVJMIG5vdCBibG9ja2VkOicsIGRldGFpbHMudXJsKTtcbiAgICB9XG59LCB7IHVybHM6IFsnPGFsbF91cmxzPiddLCB0eXBlczogWydtYWluX2ZyYW1lJ10gfSwgWydibG9ja2luZyddKTtcbi8vIEluamVjdCBjb250ZW50IHNjcmlwdCB0byBoaWRlIHNlY3Rpb25zIG9uIGFsbG93ZWQtYnV0LXJlc3RyaWN0ZWQgc2l0ZXNcbmJyb3dzZXIudGFicy5vblVwZGF0ZWQuYWRkTGlzdGVuZXIoKHRhYklkLCBjaGFuZ2VJbmZvLCB0YWIpID0+IHtcbiAgICBpZiAoY2hhbmdlSW5mby5zdGF0dXMgIT09ICdjb21wbGV0ZScgfHwgIXRhYi51cmwpXG4gICAgICAgIHJldHVybjtcbiAgICBjb25zdCBoaWRlQ29uZmlnID0gZ2V0SGlkZUNvbmZpZyh0YWIudXJsKTtcbiAgICBpZiAoIWhpZGVDb25maWcpXG4gICAgICAgIHJldHVybjtcbiAgICBjb25zdCB7IHNlbGVjdG9yIH0gPSBoaWRlQ29uZmlnO1xuICAgIGJyb3dzZXIudGFicy5leGVjdXRlU2NyaXB0KHRhYklkLCB7XG4gICAgICAgIGNvZGU6IGBcbiAgICAgICAgKGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICBjb25zdCBTRUxFQ1RPUiA9ICR7SlNPTi5zdHJpbmdpZnkoc2VsZWN0b3IpfTtcblxuICAgICAgICAgIGZ1bmN0aW9uIGhpZGVFbGVtZW50cygpIHtcbiAgICAgICAgICAgIGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3JBbGwoU0VMRUNUT1IpLmZvckVhY2goKGVsKSA9PiB7XG4gICAgICAgICAgICAgIGVsLnN0eWxlLnNldFByb3BlcnR5KCdkaXNwbGF5JywgJ25vbmUnLCAnaW1wb3J0YW50Jyk7XG4gICAgICAgICAgICB9KTtcbiAgICAgICAgICB9XG5cbiAgICAgICAgICAvLyBSdW4gaW1tZWRpYXRlbHkgb24gbG9hZFxuICAgICAgICAgIGhpZGVFbGVtZW50cygpO1xuXG4gICAgICAgICAgLy8gV2F0Y2ggZm9yIGR5bmFtaWNhbGx5IGluamVjdGVkIGVsZW1lbnRzIChZb3VUdWJlIGlzIGFuIFNQQSlcbiAgICAgICAgICBjb25zdCBvYnNlcnZlciA9IG5ldyBNdXRhdGlvbk9ic2VydmVyKGhpZGVFbGVtZW50cyk7XG4gICAgICAgICAgb2JzZXJ2ZXIub2JzZXJ2ZShkb2N1bWVudC5ib2R5LCB7IGNoaWxkTGlzdDogdHJ1ZSwgc3VidHJlZTogdHJ1ZSB9KTtcbiAgICAgICAgfSkoKTtcbiAgICAgIGAsXG4gICAgfSk7XG59KTtcbiJdLCJuYW1lcyI6W10sInNvdXJjZVJvb3QiOiIifQ==